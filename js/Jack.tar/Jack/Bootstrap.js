(function($) {

	//Singleton
	Jack.Bootstrap = {

		_init : function()
		{
			//
		}

	}

})(jQuery);