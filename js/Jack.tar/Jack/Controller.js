(function($) {

	//Singleton
	Jack.Controller = {

		view : null

	}

})(jQuery);